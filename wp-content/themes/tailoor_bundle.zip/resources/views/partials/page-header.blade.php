<div class="page-header container">
  <h1 class="text-4xl font-header text-center font-bold mb-16">{!! $title !!}</h1>
</div>
