{{--
  Template Name: Landing page
--}}
@php($header = 'sections.header-landing')
@extends('layouts.landing')

