<?php

use App\View\Components\RequestForm;

$props = [
  'firstname' => old('first_name', fake()->firstName()),
  'lastname' => old('last_name', fake()->lastName()),
  'phone' => old('phone', fake()->e164PhoneNumber()),
  'email' => old('email', fake()->companyEmail()),
  'company' => old('company', fake()->company()),
  'website' => old('website', fake()->url()),
  'platform' => old('platform', fake()->randomElement(array_keys(RequestForm::platforms()))),
  'business' => old('business', fake()->randomElement(array_keys(RequestForm::businessType()))),
  'city' => old('city', fake()->city()),
  'country' => old('country', fake()->randomElement(array_keys(RequestForm::countries()))),
  'note' => old('note', fake()->boolean(30) ? fake()->paragraph(1) : null),
  'privacy' => true,
  'newsletter' => fake()->boolean(15),
];


\App\Http\Controllers\HubspotController::getInstance()->store($props);
